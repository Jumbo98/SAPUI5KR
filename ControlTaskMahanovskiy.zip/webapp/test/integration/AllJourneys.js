/*global QUnit*/

jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"zjbcourses/ControlTaskMahanovskiy/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"zjbcourses/ControlTaskMahanovskiy/test/integration/pages/Worklist",
	"zjbcourses/ControlTaskMahanovskiy/test/integration/pages/Object",
	"zjbcourses/ControlTaskMahanovskiy/test/integration/pages/NotFound",
	"zjbcourses/ControlTaskMahanovskiy/test/integration/pages/Browser",
	"zjbcourses/ControlTaskMahanovskiy/test/integration/pages/App"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "zjbcourses.ControlTaskMahanovskiy.view."
	});

	sap.ui.require([
		"zjbcourses/ControlTaskMahanovskiy/test/integration/WorklistJourney",
		"zjbcourses/ControlTaskMahanovskiy/test/integration/ObjectJourney",
		"zjbcourses/ControlTaskMahanovskiy/test/integration/NavigationJourney",
		"zjbcourses/ControlTaskMahanovskiy/test/integration/NotFoundJourney"
	], function () {
		QUnit.start();
	});
});